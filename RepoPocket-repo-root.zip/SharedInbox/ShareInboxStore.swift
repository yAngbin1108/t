import Foundation

struct ShareInboxItem: Codable, Identifiable {
    let id: UUID
    let name: String
    let size: Int64
    let created: Date
}

enum ShareInboxError: LocalizedError {
    case unavailable, invalidFile, invalidItem
    var errorDescription: String? {
        switch self {
        case .unavailable: return "共享文件夹不可用：签名里没有可用的 App Group，分享扩展无法把文件交给主程序。请在签名工具（ESign/SideStore）中为“主程序 + RepoPocketShare 扩展”配置同一个 App Group 后重签；或在 App 内用「导入文件」直接添加待上传文件，无需 App Group。"
        case .invalidFile: return "只能导入普通文件；文件夹请先压缩为 ZIP。"
        case .invalidItem: return "文件已移除或路径无效，请刷新列表。"
        }
    }
}

/// Only owns UUID children under its private inbox. Source URLs are never mutated.
struct ShareInboxStore {
    /// App Group shipped by upstream and used verbatim under TrollStore.
    static let defaultGroup = "group.com.wm0104.RepoPocket.shared"

    /// Resolved App Group identifier, or nil when this installation owns no candidate container.
    /// Computed per call rather than cached: the first successful share import provisions a missing
    /// container, and a cached nil would then stay wrong for the rest of the process.
    ///
    /// iOS only hands out a shared container when that group is registered to the *signing
    /// identity's* team prefix, so `defaultGroup` works as-is for a TrollStore install but
    /// `containerURL(forSecurityApplicationGroupIdentifier:)` returns nil after an ESign /
    /// SideStore / AltStore re-sign — which surfaced as "共享文件夹不可用". Re-signing tools rewrite
    /// entitlements and cannot invent an App Group registration, so several spellings are probed.
    /// The first candidate with a live container wins; `defaultGroup` is still tried last so an
    /// existing TrollStore install keeps seeing the files it already imported.
    static var group: String? { resolvedGroup() }

    /// App Group this installation can actually use, or nil when none of the candidates has a
    /// container. `provision` creates the directory for the first readable candidate so a re-signed
    /// install that was granted the group can start using it immediately instead of staying empty.
    @discardableResult
    static func resolvedGroup(provision: Bool = false) -> String? {
        var provisioned: String?
        for candidate in candidates {
            guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: candidate) else { continue }
            if !provision { return candidate }
            // A container URL that cannot be created is not usable yet; keep probing alternatives.
            if (try? FileManager.default.createDirectory(at: container.appendingPathComponent("Library/Application Support/ShareInbox", isDirectory: true), withIntermediateDirectories: true)) != nil {
                return candidate
            }
            if provisioned == nil { provisioned = candidate }
        }
        return provisioned
    }

    /// Groups this installation could plausibly own, most specific first.
    ///
    /// iOS exposes no public API for reading one's own signed entitlements (`SecCode` and
    /// `SecCodeCopySigningInformation` are macOS-only and absent from the iOS SDK), so candidates
    /// are derived from information that *is* reachable: an explicit Info.plist override, the
    /// team-prefixed spelling used by free-provisioning re-signs, and the upstream name. The real
    /// test is `containerURL(forSecurityApplicationGroupIdentifier:)` in `resolvedGroup`, not the
    /// name — a wrong guess simply fails the probe and the next candidate is tried.
    static var candidates: [String] {
        var found: [String] = []
        func add(_ candidate: String?) {
            guard let candidate, !candidate.isEmpty, !found.contains(candidate) else { return }
            found.append(candidate)
        }
        // An explicit override leads, for builds that know their own group ahead of time.
        add(Bundle.main.object(forInfoDictionaryKey: "RPShareGroupIdentifier") as? String)
        // Team-prefixed spelling used by free-provisioning re-signs, e.g.
        // group.LH5TQ2SX7K.com.wm0104.RepoPocket.shared
        let suffix = String(defaultGroup.dropFirst("group.".count))
        if let identifier = Bundle.main.bundleIdentifier {
            let team = String(identifier.prefix(while: { $0 != "." }))
            // Real team identifiers are 10 alphanumerics; a 9+ uppercase/digit run is a safe filter
            // that also rejects bundle ids like `com.wm0104.RepoPocket`.
            if team.count >= 9, team.range(of: "^[A-Z0-9]{9,}$", options: .regularExpression) != nil {
                add("group." + team + "." + suffix)
            }
        }
        add(defaultGroup)
        return found
    }

    let root: URL
    /// True when `root` lives in an App Group container, i.e. the share extension can reach it too.
    /// Defaults to false so the direct-initialising test fixtures keep their single-argument form.
    let isShared: Bool

    init(root: URL, isShared: Bool = false) {
        self.root = root
        self.isShared = isShared
    }

    /// Whether this binary is the share extension rather than the host app.
    ///
    /// The extension must never fall back to its own sandbox: files written there are invisible to
    /// the app, which is worse than a clear error. Only the host app may relocate the inbox.
    static var isRunningInExtension: Bool {
        Bundle.main.bundleURL.pathExtension == "appex"
    }

    static func live() throws -> ShareInboxStore {
        if let group = resolvedGroup(provision: true),
           let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) {
            return ShareInboxStore(root: container.appendingPathComponent("Library/Application Support/ShareInbox", isDirectory: true), isShared: true)
        }
        guard !isRunningInExtension else { throw ShareInboxError.unavailable }
        // No App Group, but the app's own sandbox still gives a usable staging area. The share
        // extension cannot write here, so the inbox is filled from inside the app instead; this is
        // what makes the feature work under re-signing tools that strip application-groups.
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return ShareInboxStore(root: base.appendingPathComponent("ShareInbox", isDirectory: true), isShared: false)
    }
    private func safeName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/") && !name.contains("\\") && !name.unicodeScalars.contains { $0.value < 32 || $0.value == 127 }
    }
    private func regular(_ file: URL) -> Bool {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: file.path) else { return false }
        return attributes[.type] as? FileAttributeType == .typeRegular
    }
    private func prepare() throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        guard (try FileManager.default.attributesOfItem(atPath: root.path))[.type] as? FileAttributeType == .typeDirectory else { throw ShareInboxError.invalidItem }
    }
    func importFile(_ source: URL, name: String? = nil, cancelled: () -> Bool = { false }) throws -> ShareInboxItem {
        let fm = FileManager.default
        let name = name ?? source.lastPathComponent
        guard safeName(name), source.isFileURL else { throw ShareInboxError.invalidFile }
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        guard regular(source) else { throw ShareInboxError.invalidFile }
        try prepare()
        let id = UUID()
        let stage = root.appendingPathComponent(".staging-" + id.uuidString, isDirectory: true)
        try fm.createDirectory(at: stage, withIntermediateDirectories: false)
        var published = false
        defer { if !published { try? fm.removeItem(at: stage) } }
        let content = stage.appendingPathComponent("content", isDirectory: true)
        try fm.createDirectory(at: content, withIntermediateDirectories: false)
        var coordinationError: NSError?
        var copyError: Error?
        NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &coordinationError) { coordinated in
            do {
                if cancelled() { throw CancellationError() }
                guard regular(coordinated) else { throw ShareInboxError.invalidFile }
                try fm.copyItem(at: coordinated, to: content.appendingPathComponent(name))
            } catch { copyError = error }
        }
        if let error = coordinationError { throw error }
        if let error = copyError { throw error }
        if cancelled() { throw CancellationError() }
        let file = content.appendingPathComponent(name)
        guard regular(file) else { throw ShareInboxError.invalidFile }
        let size = (try fm.attributesOfItem(atPath: file.path)[.size] as? NSNumber)?.int64Value ?? 0
        let item = ShareInboxItem(id: id, name: name, size: size, created: Date())
        try JSONEncoder().encode(item).write(to: stage.appendingPathComponent("metadata.json"), options: .atomic)
        if cancelled() { throw CancellationError() }
        try fm.moveItem(at: stage, to: root.appendingPathComponent(id.uuidString, isDirectory: true))
        published = true
        return item
    }
    func file(_ item: ShareInboxItem) throws -> URL {
        let folder = root.appendingPathComponent(item.id.uuidString, isDirectory: true)
        let content = folder.appendingPathComponent("content", isDirectory: true)
        guard safeName(item.name),
              (try? FileManager.default.attributesOfItem(atPath: folder.path)[.type] as? FileAttributeType) == .typeDirectory,
              (try? FileManager.default.attributesOfItem(atPath: content.path)[.type] as? FileAttributeType) == .typeDirectory else { throw ShareInboxError.invalidItem }
        let file = content.appendingPathComponent(item.name)
        guard regular(file), file.resolvingSymlinksInPath().deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent().path == root.resolvingSymlinksInPath().path else { throw ShareInboxError.invalidItem }
        return file
    }
    func items() throws -> [ShareInboxItem] {
        try prepare()
        return try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil).compactMap { folder -> ShareInboxItem? in
            guard let id = UUID(uuidString: folder.lastPathComponent),
                  (try? FileManager.default.attributesOfItem(atPath: folder.path)[.type] as? FileAttributeType) == .typeDirectory,
                  let data = try? Data(contentsOf: folder.appendingPathComponent("metadata.json")),
                  let item = try? JSONDecoder().decode(ShareInboxItem.self, from: data), item.id == id,
                  (try? file(item)) != nil else { return nil }
            return item
        }.sorted { $0.created > $1.created }
    }
    func remove(_ item: ShareInboxItem) throws {
        _ = try file(item)
        try FileManager.default.removeItem(at: root.appendingPathComponent(item.id.uuidString, isDirectory: true))
    }
    /// A picker exports disposable copies, so deleting an inbox row cannot invalidate an upload.
    func stage(_ items: [ShareInboxItem]) throws -> [URL] {
        let fm = FileManager.default
        let stage = fm.temporaryDirectory.appendingPathComponent("ShareSelection-" + UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: stage, withIntermediateDirectories: false)
        do {
            return try items.map { item in
                let folder = stage.appendingPathComponent(item.id.uuidString, isDirectory: true)
                try fm.createDirectory(at: folder, withIntermediateDirectories: false)
                let target = folder.appendingPathComponent(item.name)
                try fm.copyItem(at: file(item), to: target)
                return target
            }
        } catch { try? fm.removeItem(at: stage); throw error }
    }
}
