import Foundation

struct ShareInboxItem: Codable, Identifiable {
    let id: UUID
    let name: String
    let size: Int64
    let created: Date
}

enum ShareInboxError: LocalizedError {
    case unavailable, invalidFile, invalidItem
    var errorDescription: String? {
        switch self {
        case .unavailable: return "共享文件夹不可用：签名里没有可用的 App Group，分享扩展无法把文件交给主程序。可改用「待上传文件」页顶部的投递目录，从“文件”App 把文件拖进去即可。"
        case .invalidFile: return "只能导入普通文件；文件夹请先压缩为 ZIP。"
        case .invalidItem: return "文件已移除或路径无效，请刷新列表。"
        }
    }
}

/// Only owns UUID children under its private inbox. Source URLs are never mutated.
struct ShareInboxStore {
    /// App Group shipped by upstream and used verbatim under TrollStore.
    static let defaultGroup = "group.com.wm0104.RepoPocket.shared"

    /// Resolved App Group identifier, or nil when this installation owns no candidate container.
    /// iOS only grants a shared container when the group is registered to the *signing identity's*
    /// team prefix, so `defaultGroup` works under TrollStore but returns nil after an ESign /
    /// SideStore re-sign — those tools rewrite entitlements from their own template, which is why
    /// baking a group into the CI signature cannot survive them.
    static var group: String? {
        for candidate in candidates where FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: candidate) != nil {
            return candidate
        }
        return nil
    }

    /// Candidate groups: an explicit Info.plist override, then the canonical upstream name last so
    /// an existing TrollStore install keeps seeing the files it already imported.
    static var candidates: [String] {
        var found: [String] = []
        if let override = Bundle.main.object(forInfoDictionaryKey: "RPShareGroupIdentifier") as? String, !override.isEmpty { found.append(override) }
        if !found.contains(defaultGroup) { found.append(defaultGroup) }
        return found
    }

    let root: URL
    /// True when `root` is an App Group container, i.e. the share extension can reach it too.
    let isShared: Bool
    init(root: URL, isShared: Bool = false) {
        self.root = root; self.isShared = isShared
    }

    /// Whether this binary is the share extension rather than the host app. The extension must never
    /// fall back to its own sandbox: a file written there is invisible to the app, which is worse
    /// than a clear error.
    static var isRunningInExtension: Bool { Bundle.main.bundleURL.pathExtension == "appex" }

    /// Inbox folder exposed to the Files app by `UIFileSharingEnabled`. Dropping files here needs no
    /// system document picker and no App Group, which is what keeps uploads working on a re-signed
    /// iOS 17.5 install where both of those have proven unreliable.
    static let dropFolderName = "待上传文件"

    static var userDropFolder: URL? {
        guard !isRunningInExtension else { return nil }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?
            .appendingPathComponent(dropFolderName, isDirectory: true)
    }

    static func live() throws -> ShareInboxStore {
        if let group, let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) {
            return ShareInboxStore(root: container.appendingPathComponent("Library/Application Support/ShareInbox", isDirectory: true), isShared: true)
        }
        guard let drop = userDropFolder else { throw ShareInboxError.unavailable }
        return ShareInboxStore(root: drop, isShared: false)
    }

    /// Plain files the user dropped into the visible inbox, excluding our own UUID package folders.
    func looseFiles() throws -> [URL] {
        try prepare()
        return try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles])
            .filter { regular($0) && UUID(uuidString: $0.deletingPathExtension().lastPathComponent) == nil }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedDescending }
    }
    private func safeName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/") && !name.contains("\\") && !name.unicodeScalars.contains { $0.value < 32 || $0.value == 127 }
    }
    private func regular(_ file: URL) -> Bool {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: file.path) else { return false }
        return attributes[.type] as? FileAttributeType == .typeRegular
    }
    private func prepare() throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        guard (try FileManager.default.attributesOfItem(atPath: root.path))[.type] as? FileAttributeType == .typeDirectory else { throw ShareInboxError.invalidItem }
    }
    func importFile(_ source: URL, name: String? = nil, cancelled: () -> Bool = { false }) throws -> ShareInboxItem {
        let fm = FileManager.default
        let name = name ?? source.lastPathComponent
        guard safeName(name), source.isFileURL else { throw ShareInboxError.invalidFile }
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        guard regular(source) else { throw ShareInboxError.invalidFile }
        try prepare()
        let id = UUID()
        let stage = root.appendingPathComponent(".staging-" + id.uuidString, isDirectory: true)
        try fm.createDirectory(at: stage, withIntermediateDirectories: false)
        var published = false
        defer { if !published { try? fm.removeItem(at: stage) } }
        let content = stage.appendingPathComponent("content", isDirectory: true)
        try fm.createDirectory(at: content, withIntermediateDirectories: false)
        var coordinationError: NSError?
        var copyError: Error?
        NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &coordinationError) { coordinated in
            do {
                if cancelled() { throw CancellationError() }
                guard regular(coordinated) else { throw ShareInboxError.invalidFile }
                try fm.copyItem(at: coordinated, to: content.appendingPathComponent(name))
            } catch { copyError = error }
        }
        if let error = coordinationError { throw error }
        if let error = copyError { throw error }
        if cancelled() { throw CancellationError() }
        let file = content.appendingPathComponent(name)
        guard regular(file) else { throw ShareInboxError.invalidFile }
        let size = (try fm.attributesOfItem(atPath: file.path)[.size] as? NSNumber)?.int64Value ?? 0
        let item = ShareInboxItem(id: id, name: name, size: size, created: Date())
        try JSONEncoder().encode(item).write(to: stage.appendingPathComponent("metadata.json"), options: .atomic)
        if cancelled() { throw CancellationError() }
        try fm.moveItem(at: stage, to: root.appendingPathComponent(id.uuidString, isDirectory: true))
        published = true
        return item
    }
    func file(_ item: ShareInboxItem) throws -> URL {
        let folder = root.appendingPathComponent(item.id.uuidString, isDirectory: true)
        let content = folder.appendingPathComponent("content", isDirectory: true)
        guard safeName(item.name),
              (try? FileManager.default.attributesOfItem(atPath: folder.path)[.type] as? FileAttributeType) == .typeDirectory,
              (try? FileManager.default.attributesOfItem(atPath: content.path)[.type] as? FileAttributeType) == .typeDirectory else { throw ShareInboxError.invalidItem }
        let file = content.appendingPathComponent(item.name)
        guard regular(file), file.resolvingSymlinksInPath().deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent().path == root.resolvingSymlinksInPath().path else { throw ShareInboxError.invalidItem }
        return file
    }
    func items() throws -> [ShareInboxItem] {
        try prepare()
        return try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil).compactMap { folder -> ShareInboxItem? in
            guard let id = UUID(uuidString: folder.lastPathComponent),
                  (try? FileManager.default.attributesOfItem(atPath: folder.path)[.type] as? FileAttributeType) == .typeDirectory,
                  let data = try? Data(contentsOf: folder.appendingPathComponent("metadata.json")),
                  let item = try? JSONDecoder().decode(ShareInboxItem.self, from: data), item.id == id,
                  (try? file(item)) != nil else { return nil }
            return item
        }.sorted { $0.created > $1.created }
    }
    func remove(_ item: ShareInboxItem) throws {
        _ = try file(item)
        try FileManager.default.removeItem(at: root.appendingPathComponent(item.id.uuidString, isDirectory: true))
    }
    /// A picker exports disposable copies, so deleting an inbox row cannot invalidate an upload.
    func stage(_ items: [ShareInboxItem]) throws -> [URL] {
        let fm = FileManager.default
        let stage = fm.temporaryDirectory.appendingPathComponent("ShareSelection-" + UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: stage, withIntermediateDirectories: false)
        do {
            return try items.map { item in
                let folder = stage.appendingPathComponent(item.id.uuidString, isDirectory: true)
                try fm.createDirectory(at: folder, withIntermediateDirectories: false)
                let target = folder.appendingPathComponent(item.name)
                try fm.copyItem(at: file(item), to: target)
                return target
            }
        } catch { try? fm.removeItem(at: stage); throw error }
    }
}
