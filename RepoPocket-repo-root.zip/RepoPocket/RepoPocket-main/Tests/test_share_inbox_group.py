"""App Group resolution for re-signed installs (the "共享文件夹不可用" report).

Upstream hard-coded `group.com.wm0104.RepoPocket.shared`, which only TrollStore honours: iOS hands
out a shared container when the group is registered to the *signing identity's* team prefix, so an
ESign / SideStore / AltStore re-sign gets nil back and the share inbox becomes unusable. The store
now probes a candidate list — explicit override, groups actually present in the code signature, the
team-prefixed spelling, then the canonical name — and reports what it found on-device via Settings →
共享存储诊断.
"""
from pathlib import Path
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]
STORE = REPO_ROOT / 'SharedInbox' / 'ShareInboxStore.swift'
DIAGNOSTICS = REPO_ROOT / 'RepoPocket' / 'ShareInboxDiagnostics.swift'
SETTINGS = REPO_ROOT / 'RepoPocket' / 'RepoPocketApp.swift'


class ShareInboxGroupTests(unittest.TestCase):
    def setUp(self):
        self.store = STORE.read_text()

    def test_group_is_resolved_not_hardcoded(self):
        self.assertIn('static let defaultGroup = "group.com.wm0104.RepoPocket.shared"', self.store)
        # `group` must be a computed/optional resolution over candidates, never a single literal.
        # Resolved per call, never cached: provisioning a container later must be picked up.
        self.assertIn('static var group: String? { resolvedGroup() }', self.store)
        self.assertIn('static func resolvedGroup(provision: Bool = false) -> String?', self.store)
        self.assertIn('guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: candidate)', self.store)
        self.assertNotIn('static let group = "group.', self.store)

    def test_candidates_cover_resign_and_trollstore_layouts(self):
        self.assertIn('"RPShareGroupIdentifier"', self.store)
        # Team-prefixed form used by free-provisioning re-signs.
        self.assertIn('add("group." + team + "." + suffix)', self.store)
        # Canonical name must be attempted last, so an existing TrollStore install keeps its files.
        additions = [index for index, line in enumerate(self.store.splitlines()) if line.strip().startswith('add(')]
        self.assertTrue(additions)
        self.assertEqual(self.store.splitlines()[additions[-1]].strip(), 'add(defaultGroup)')

    def test_shared_file_avoids_api_that_is_absent_or_forbidden(self):
        # `SharedInbox/` compiles into the share extension as well. Two constraints, both of which
        # broke a real build: UIKit is disallowed under APPLICATION_EXTENSION_API_ONLY, and the
        # SecCode family (SecCodeCopySelf / SecCodeCopySigningInformation) simply does not exist in
        # the iOS SDK — it is macOS-only, so importing Security and calling it fails to compile.
        self.assertNotIn('import Security', self.store)
        self.assertNotIn('import UIKit', self.store)
        code_lines = [line for line in self.store.splitlines() if not line.strip().startswith('//')]
        for forbidden in ('SecCodeCopySelf', 'SecCodeCopySigningInformation', 'SecCSFlags(', 'kSecCSSigningInformation'):
            self.assertFalse(any(forbidden in line for line in code_lines), forbidden)
        # The probe itself must remain: it is the only trustworthy signal on iOS.
        self.assertIn('containerURL(forSecurityApplicationGroupIdentifier:', self.store)

    def test_live_store_uses_resolved_group_and_explains_failure(self):
        self.assertIn('guard let group = resolvedGroup(provision: true), let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)', self.store)
        message = [line for line in self.store.splitlines() if '共享文件夹不可用' in line][0]
        # The old copy told users to "use an install method that supports the share extension",
        # which is not actionable; it must now name the real fix.
        self.assertIn('App Group', message)
        self.assertIn('再签', message)
        self.assertNotIn('请确认使用支持分享扩展的安装方式', message)

    def test_diagnostics_screen_reports_resolution_on_device(self):
        diagnostics = DIAGNOSTICS.read_text()
        self.assertIn('struct ShareInboxDiagnosticsView: View', diagnostics)
        self.assertIn('ShareInboxStore.candidates', diagnostics)
        self.assertIn('ShareInboxStore.group', diagnostics)
        self.assertIn('containerURL(forSecurityApplicationGroupIdentifier:', diagnostics)
        # Read-only: the screen must never delete or move inbox contents.
        for forbidden in ('removeItem', 'ShareInboxStore.live().remove', 'stage('):
            self.assertNotIn(forbidden, diagnostics)
        self.assertIn('NavigationLink { ShareInboxDiagnosticsView() }', SETTINGS.read_text())

    def test_shared_file_stays_extension_safe(self):
        # SharedInbox/ compiles into the app extension too, which forbids UIKit.
        self.assertNotIn('import UIKit', self.store)
        project = (REPO_ROOT / 'project.yml').read_text()
        self.assertIn('sources: [ShareExtension, SharedInbox]', project)
        self.assertIn('APPLICATION_EXTENSION_API_ONLY: YES', project)


if __name__ == '__main__':
    unittest.main()
