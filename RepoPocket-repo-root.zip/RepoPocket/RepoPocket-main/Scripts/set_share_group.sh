#!/bin/sh
# Rewrite the App Group identifier in both entitlements plists before signing.
set -euo pipefail
cd "$(dirname "$0")/.."

group=${1:-}
if [ -z "$group" ]; then
  echo 'Usage: Scripts/set_share_group.sh group.<TEAMID>.com.wm0104.RepoPocket.shared [APPID_PREFIX]' >&2
  echo '  group.<TEAMID>.com.wm0104.RepoPocket.shared: e.g., group.AB12CD34EF.com.wm0104.RepoPocket.shared' >&2
  echo '  APPID_PREFIX: Team ID (extracted from group if not given)' >&2
  exit 2
fi
case "$group" in
  group.*) ;;
  *) echo "App Group must start with 'group.': $group" >&2; exit 2;;
esac
prefix=${2:-$(echo "$group" | cut -d. -f2)}
if [ -z "$prefix" ] || [ "$group" = "$prefix" ]; then
  echo "Cannot derive Team ID from group: $group" >&2
  exit 2
fi

for plist in Entitlements.plist ShareExtension/Entitlements.plist; do
  if [ ! -f "$plist" ]; then
    echo "Missing: $plist (from directory $PWD)" >&2
    exit 1
  fi
  /usr/libexec/PlistBuddy -c "Delete :com.apple.security.application-groups:0" "$plist" >/dev/null 2>&1 || true
  /usr/libexec/PlistBuddy -c "Add :com.apple.security.application-groups:0 string $group" "$plist"
  echo "--- $plist ---"
  /usr/libexec/PlistBuddy -c "Print :com.apple.security.application-groups" "$plist"
  echo "--- team-identifier set to: $prefix ---"
  /usr/libexec/PlistBuddy -c "Set :com.apple.developer.team-identifier $prefix" "$plist"
done
