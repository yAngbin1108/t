import SwiftUI
import UniformTypeIdentifiers
import UIKit

// One immutable request is both the sheet identity and its import mode.
struct WorkspaceImportRequest: Identifiable {
    enum Kind: Equatable { case folder, zip, files, custom([UTType])
        var customTypes: [UTType]? { if case .custom(let types) = self { return types }; return nil }
    }
    let id = UUID()
    let kind: Kind
    var isZIP: Bool { kind == .zip }
}

// Native picker avoids the SwiftUI document-import regressions: the iOS 16 folder-provider bugs
// and, on iOS 17.5 sideloaded (self-signed) installs, a document picker whose "Open" action never
// completes — neither URLs nor a cancellation ever reach the caller.
struct WorkspaceDocumentPicker: UIViewControllerRepresentable {
    let request: WorkspaceImportRequest
    var allowsMultipleSelection = true
    var cancelTitle = "取消导入"
    var initialDirectoryURL: URL? = nil
    let completion: ([URL]?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion) }
    func makeUIViewController(context: Context) -> WorkspacePickerContainer {
        let types: [UTType] = request.kind.customTypes ?? (request.kind == .files ? [.item] : (request.isZIP ? [.zip] : [.folder]))
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        picker.allowsMultipleSelection = allowsMultipleSelection
        picker.directoryURL = initialDirectoryURL
        picker.delegate = context.coordinator
        return WorkspacePickerContainer(picker: picker, showCancel: !request.isZIP, cancelTitle: cancelTitle, cancel: { context.coordinator.finish(nil) })
    }
    func updateUIViewController(_ controller: WorkspacePickerContainer, context: Context) {
        context.coordinator.completion = completion
    }
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        var completion: ([URL]?) -> Void
        private var finished = false
        init(_ completion: @escaping ([URL]?) -> Void) { self.completion = completion }
        func finish(_ urls: [URL]?) {
            guard !finished else { return }
            finished = true
            completion(urls)
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { finish(urls) }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(nil) }
    }
}

/// Presents the document picker modally and guarantees a Cancel action.
///
/// The picker used to be embedded with `addChild`, purely so the app could keep its own Cancel
/// button visible when a Files provider hides the system one. That embedding is the reason
/// selecting a file did nothing: `UIDocumentPickerViewController` completes its "Open" action by
/// dismissing *its presenting controller* and only then delivers `didPickDocumentsAt`. As a child
/// it has no presenting controller, so on iOS 17 the tap is silently dropped — the sheet stays open
/// and no URL ever arrives. Presenting modally restores the supported contract; Cancel is injected
/// into the picker's own navigation bar instead of living outside it.
final class WorkspacePickerContainer: UIViewController {
    private let picker: UIDocumentPickerViewController
    private let showCancel: Bool
    private let cancelTitle: String
    private let cancel: () -> Void
    private var presented = false

    init(picker: UIDocumentPickerViewController, showCancel: Bool, cancelTitle: String = "取消导入", cancel: @escaping () -> Void) {
        self.picker = picker; self.showCancel = showCancel; self.cancelTitle = cancelTitle; self.cancel = cancel
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        // The host never shows UI of its own; it exists only to own the presentation.
        view.backgroundColor = .clear
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !presented, presentedViewController == nil else { return }
        presented = true
        present(picker, animated: true) { [weak self] in self?.installCancelIfNeeded() }
    }

    /// A provider that ships its own Cancel keeps it; otherwise the user would be trapped in a
    /// sheet they cannot dismiss. Applied to the visible top controller because the navigation
    /// controller's own item is not what Files renders.
    private func installCancelIfNeeded() {
        guard showCancel else { return }
        let target = picker.topViewController ?? picker
        if hasVisibleCancel(target) || hasVisibleCancel(picker) { return }
        let button = UIBarButtonItem(title: cancelTitle, style: .plain, target: self, action: #selector(cancelImport))
        button.accessibilityIdentifier = "workspace.import.cancel"
        target.navigationItem.leftBarButtonItem = button
        picker.navigationItem.leftBarButtonItem = button
    }

    private func hasVisibleCancel(_ controller: UIViewController) -> Bool {
        let items = [controller.navigationItem.leftBarButtonItem] + controller.navigationItem.leftBarButtonItems
        return items.contains { $0?.title == cancelTitle || $0?.style == .done }
    }

    @objc private func cancelImport() { cancel() }
}
