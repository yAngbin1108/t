import SwiftUI

/// Read-only view of the App Group this installation actually resolved, so a "共享文件夹不可用"
/// report can be diagnosed on-device instead of guessed at. Shows every candidate that was tried,
/// which one won, and how many files the inbox currently sees.
struct ShareInboxDiagnosticsView: View {
    @State private var lines: [String] = []
    @State private var count = 0

    var body: some View {
        List {
            Section {
                Text("如果“待上传文件”提示共享文件夹不可用，本页会显示本机实际拿到的 App Group。自签工具重签时，主程序与分享扩展必须配置成同一个 group。").font(.caption).softGroupedRow(top: true, bottom: true)
            }
            Section("解析结果") {
                ForEach(Array(lines.enumerated()), id: \.offset) { _, line in
                    Text(line).font(.system(.caption, design: .monospaced)).textSelection(.enabled).softGroupedRow()
                }
                if lines.isEmpty { Text("正在读取…").softGroupedRow(top: true, bottom: true) }
            }
            Section("当前收件箱") {
                Text(count == 0 ? "0 个文件（或容器不可用）" : "\(count) 个文件").softGroupedRow(top: true, bottom: true)
            }
        }
        .navigationTitle("共享存储诊断")
        .navigationBarTitleDisplayMode(.inline)
        .task { load() }
    }

    private func load() {
        let candidates = ShareInboxStore.candidates
        let resolved = ShareInboxStore.group
        let store = try? ShareInboxStore.live()
        var output: [String] = []
        output.append("bundle id：" + (Bundle.main.bundleIdentifier ?? "—"))
        output.append("运行位置：" + (ShareInboxStore.isRunningInExtension ? "分享扩展" : "主程序"))
        output.append("共享容器：" + (resolved ?? "无 → 扩展导入不可用，App 内「导入文件」仍可用"))
        output.append("收件箱：" + (store.map { $0.isShared ? "共享容器" : "App 沙盒（仅 App 内导入可用）" } ?? "不可用"))
        output.append("路径：" + (store?.root.path ?? "—"))
        output.append("候选列表：")
        for candidate in candidates {
            let available = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: candidate) != nil
            output.append((available ? "  ✓ " : "  ✗ ") + candidate)
        }
        lines = output
        if let store { count = (try? store.items().count) ?? 0 } else { count = 0 }
    }
}
