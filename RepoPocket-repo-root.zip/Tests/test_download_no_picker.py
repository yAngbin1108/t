"""Downloads must not depend on the document picker.

On a re-signed iOS 17.5 install `UIDocumentPickerViewController` never completes: tapping "Open"
returns neither a URL nor a cancellation. Because the download folder was chosen through that
picker, every download was blocked behind a step that could not finish. The app now keeps its own
`Documents/RepoPocket` target (visible in the Files app via `UIFileSharingEnabled`) and only uses
the picker as an optional upgrade.
"""
from pathlib import Path
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]
RULES = (REPO_ROOT / 'RepoPocket' / 'DownloadRules.swift').read_text()
STORE = (REPO_ROOT / 'RepoPocket' / 'DownloadStore.swift').read_text()


class PickerFreeDownloadTests(unittest.TestCase):
    def test_internal_folder_exists_and_is_extension_safe(self):
        self.assertIn('static var internalFolder: URL?', RULES)
        self.assertIn('.documentDirectory', RULES)
        # Shared with nothing, but the guard documents that only the host app owns this folder.
        self.assertIn('Bundle.main.bundleURL.pathExtension != "appex"', RULES)
        # Reusing destinationFolder keeps the on-disk name identical to the external case.
        self.assertIn('map { destinationFolder(in: $0) }', RULES)

    def test_no_bookmark_falls_back_instead_of_asking_for_a_picker(self):
        self.assertIn('guard let fallback = DownloadRules.internalFolder else', STORE)
        self.assertIn('try FileManager.default.createDirectory(at: fallback, withIntermediateDirectories: true)', STORE)
        # resolve() returns the *parent* so persist()'s destinationFolder() stays idempotent.
        self.assertIn('return fallback.deletingLastPathComponent()', STORE)

    def test_security_scope_is_skipped_for_in_sandbox_targets(self):
        # startAccessingSecurityScopedResource() can report failure for a path the app already owns,
        # which would have blocked every internal download.
        self.assertIn('static func isInternal(_ url: URL) -> Bool', STORE)
        self.assertIn('let scoped = DownloadStore.isInternal(parent) || parent.startAccessingSecurityScopedResource()', STORE)
        self.assertIn('if !DownloadStore.isInternal(parent) { parent.stopAccessingSecurityScopedResource() }', STORE)

    def test_user_can_switch_to_the_app_folder_without_a_picker(self):
        self.assertIn('func useAppFolder()', STORE)
        self.assertIn('UserDefaults.standard.removeObject(forKey: bookmarkKey)', STORE)
        self.assertIn('Button("改用 App 内目录") { store.useAppFolder() }', STORE)
        # The hint must name the failure and the workaround, not just the happy path.
        self.assertIn('点了没反应', STORE)
        self.assertIn('我的 iPhone → RepoPocket', STORE)

    def test_initial_label_reflects_the_picker_free_default(self):
        self.assertIn('App 内：', RULES)
        # requireAuthorization already returns early once resolve() succeeds without a bookmark,
        # so no picker is presented for a plain download.
        self.assertIn('if (try? resolve()) != nil { return }', STORE)


if __name__ == '__main__':
    unittest.main()
