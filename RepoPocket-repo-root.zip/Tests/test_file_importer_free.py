"""iOS 17.5 sideload regression: file upload/download must never use SwiftUI fileImporter.

On iOS 17.5.x with a self-signed / TrollStore-injected install, the document picker that
SwiftUI's `.fileImporter` presents fails to complete: tapping "Open" returns nothing at all
(no URLs, no cancellation), so uploads and any folder-selection step become unusable. The
app's own native `WorkspaceDocumentPicker` (a direct UIDocumentPickerViewController wrapper)
is unaffected, which is why Git import and the download-location picker kept working.

Every file/folder selection surface therefore goes through WorkspaceDocumentPicker presented
with `sheet(item:)`, carrying an immutable per-request identity and explicit content types.
"""
from pathlib import Path
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]
SOURCES = REPO_ROOT / 'RepoPocket'


class FileImporterFreeTests(unittest.TestCase):
    def swift(self, name):
        return (SOURCES / name).read_text()

    def test_no_view_uses_swiftui_file_importer(self):
        offenders = sorted(p.name for p in SOURCES.glob('*.swift') if '.fileImporter' in p.read_text())
        # No source may reference the modifier at all, not even in a comment.
        self.assertEqual(offenders, [])
        wrapper = self.swift('WorkspaceDocumentPicker.swift')
        self.assertIn('// Native picker avoids', wrapper)
        self.assertNotIn('.fileImporter(isPresented', wrapper)

    def test_native_wrapper_supports_explicit_content_types(self):
        wrapper = self.swift('WorkspaceDocumentPicker.swift')
        self.assertIn('case folder, zip, files, custom([UTType])', wrapper)
        self.assertIn('request.kind.customTypes ??', wrapper)
        self.assertIn('UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)', wrapper)

    def test_upload_picker_presents_native_sheet_with_request_identity(self):
        upload = self.swift('UploadView.swift')
        self.assertIn('@State private var pickerRequest: WorkspaceImportRequest?', upload)
        self.assertIn('.sheet(item: $pickerRequest)', upload)
        self.assertIn('WorkspaceDocumentPicker(request: request', upload)
        self.assertIn('.id(request.id)', upload)
        # TrollFools mode still restricts the selection to .dylib via explicit types.
        self.assertIn('kind: .custom([UTType(filenameExtension: "dylib") ?? .data])', upload)
        self.assertIn('WorkspaceImportRequest(kind: .files)', upload)
        # A cancelled picker must not enqueue an empty selection.
        self.assertIn('guard let urls, !urls.isEmpty else { return }', upload)

    def test_release_and_deb_editors_use_the_same_route(self):
        releases = self.swift('ReleaseManagementUI.swift')
        self.assertEqual(releases.count('.sheet(item: $pickerRequest)'), 1)
        self.assertEqual(releases.count('.sheet(item: $attachmentPickerRequest)'), 1)
        self.assertIn('WorkspaceDocumentPicker(request: request, allowsMultipleSelection: true', releases)
        deb = self.swift('DebEditorView.swift')
        self.assertIn('.sheet(item: $pickerRequest)', deb)
        self.assertIn('WorkspaceDocumentPicker(request: request, allowsMultipleSelection: false', deb)

    def test_download_location_keeps_single_native_entry_point(self):
        # Downloads resolve their destination through DownloadStore's folder request, which is
        # presented by the app root as a native picker; no fileImporter path may reappear there.
        app = self.swift('RepoPocketApp.swift')
        self.assertIn('WorkspaceDocumentPicker(request: request', app)
        store = self.swift('DownloadStore.swift')
        self.assertIn('WorkspaceImportRequest(kind: .folder)', store)


if __name__ == '__main__':
    unittest.main()
