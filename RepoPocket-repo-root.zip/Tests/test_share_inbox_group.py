"""App Group resolution for re-signed installs (the "共享文件夹不可用" report).

Upstream hard-coded `group.com.wm0104.RepoPocket.shared`, which only TrollStore honours: iOS hands
out a shared container when the group is registered to the *signing identity's* team prefix, so an
ESign / SideStore / AltStore re-sign gets nil back and the share inbox becomes unusable. The store
now probes a candidate list — explicit override, groups actually present in the code signature, the
team-prefixed spelling, then the canonical name — and reports what it found on-device via Settings →
共享存储诊断.
"""
from pathlib import Path
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]
STORE = REPO_ROOT / 'SharedInbox' / 'ShareInboxStore.swift'
DIAGNOSTICS = REPO_ROOT / 'RepoPocket' / 'ShareInboxDiagnostics.swift'
SETTINGS = REPO_ROOT / 'RepoPocket' / 'RepoPocketApp.swift'


class ShareInboxGroupTests(unittest.TestCase):
    def setUp(self):
        self.store = STORE.read_text()

    def test_group_is_resolved_not_hardcoded(self):
        self.assertIn('static let defaultGroup = "group.com.wm0104.RepoPocket.shared"', self.store)
        # `group` must be a computed/optional resolution over candidates, never a single literal.
        # Resolved per call, never cached: provisioning a container later must be picked up.
        self.assertIn('static var group: String? {', self.store)
        self.assertIn('for candidate in candidates where FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: candidate) != nil', self.store)
        self.assertIn('return nil', self.store)
        self.assertNotIn('static let group = "group.', self.store)

    def test_candidates_prefer_override_and_keep_canonical_last(self):
        self.assertIn('"RPShareGroupIdentifier"', self.store)
        lines = [line.strip() for line in self.store.splitlines()]
        override = next(i for i, l in enumerate(lines) if 'found.append(override)' in l)
        canonical = next(i for i, l in enumerate(lines) if 'found.append(defaultGroup)' in l)
        self.assertLess(override, canonical, 'the explicit override must be probed first')

    def test_live_store_prefers_container_then_falls_back_to_visible_folder(self):
        self.assertIn('if let group, let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)', self.store)
        # The fallback must be a folder the Files app can see, not Application Support: with the
        # document picker broken on re-signed iOS 17.5 installs, dragging a file in is the only
        # remaining way to stage an upload without an App Group.
        self.assertIn('static let dropFolderName = "待上传文件"', self.store)
        self.assertIn('.documentDirectory', self.store)
        self.assertIn('guard let drop = userDropFolder else { throw ShareInboxError.unavailable }', self.store)
        self.assertIn('return ShareInboxStore(root: drop, isShared: false)', self.store)
        # Loose files are adopted into packages so the existing row/delete/upload model is reused.
        self.assertIn('func looseFiles() throws -> [URL]', self.store)
        self.assertIn('UUID(uuidString: $0.deletingPathExtension().lastPathComponent) == nil', self.store)
        # Only the host app may fall back; the extension writing privately strands files.
        self.assertIn('Bundle.main.bundleURL.pathExtension == "appex"', self.store)
        self.assertIn('init(root: URL, isShared: Bool = false)', self.store)

    def test_in_app_import_replaces_the_extension_path(self):
        inbox = (REPO_ROOT / 'RepoPocket' / 'ShareInboxView.swift').read_text()
        # The inbox must be fillable without the share extension, otherwise re-signed installs
        # (which lose application-groups) have no way to stage files at all.
        self.assertIn('Button { importRequest = WorkspaceImportRequest(kind: .files) }', inbox)
        self.assertIn('Label("导入文件"', inbox)
        self.assertIn('.sheet(item: $importRequest)', inbox)
        self.assertIn('WorkspaceDocumentPicker(request: request, allowsMultipleSelection: true', inbox)
        self.assertIn('try store.importFile($0)', inbox)
        # The copy runs off the main actor: importing several large files must not freeze the UI.
        self.assertIn('Task.detached { () -> [ShareInboxItem] in', inbox)
        # Storage mode is surfaced instead of silently mislabeling the inbox as shared.
        self.assertIn('let found = try await Task.detached { () -> ([ShareInboxItem], Bool) in', inbox)
        self.assertIn('store.items(), store.isShared', inbox)
        self.assertIn('把要上传的文件拖进去', inbox)

    def test_diagnostics_screen_reports_resolution_on_device(self):
        diagnostics = DIAGNOSTICS.read_text()
        self.assertIn('struct ShareInboxDiagnosticsView: View', diagnostics)
        self.assertIn('ShareInboxStore.candidates', diagnostics)
        self.assertIn('ShareInboxStore.group', diagnostics)
        self.assertIn('containerURL(forSecurityApplicationGroupIdentifier:', diagnostics)
        # Read-only: the screen must never delete or move inbox contents.
        for forbidden in ('removeItem', 'ShareInboxStore.live().remove', 'stage('):
            self.assertNotIn(forbidden, diagnostics)
        self.assertIn('NavigationLink { ShareInboxDiagnosticsView() }', SETTINGS.read_text())

    def test_shared_file_stays_extension_safe(self):
        # SharedInbox/ compiles into the app extension too, which forbids UIKit.
        self.assertNotIn('import UIKit', self.store)
        project = (REPO_ROOT / 'project.yml').read_text()
        self.assertIn('sources: [ShareExtension, SharedInbox]', project)
        self.assertIn('APPLICATION_EXTENSION_API_ONLY: YES', project)


if __name__ == '__main__':
    unittest.main()
