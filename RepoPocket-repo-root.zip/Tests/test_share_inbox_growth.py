"""Storage-growth regression: adopting a dropped file must consume it, not duplicate it.

Reported on a re-signed iOS 17.5 install: the inbox falls back to a folder inside Documents so the
user can drag files in from the Files app. The adoption step copied each dropped file into its own
package but left the original in place, so every refresh produced another full copy and storage grew
without bound (the user saw Lab.ipa, Lab 2.ipa, Lab1.0.ipa … pile up).

These tests check the Swift source for the two guards, and simulate the resulting algorithm on a
real filesystem to prove it converges.
"""
from pathlib import Path
import os
import shutil
import tempfile
import unittest

REPO_ROOT = Path(__file__).resolve().parents[1]
STORE = (REPO_ROOT / 'SharedInbox' / 'ShareInboxStore.swift').read_text()
VIEW = (REPO_ROOT / 'RepoPocket' / 'ShareInboxView.swift').read_text()


class DropFolderGrowthTests(unittest.TestCase):
    def test_adoption_removes_the_dropped_original(self):
        self.assertIn('if isInsideInbox(source) { try? fm.removeItem(at: source) }', STORE)
        # The containment test compares the *parent* directory, so packaged copies under a UUID
        # folder and files from outside the inbox are never deleted.
        self.assertIn('func isInsideInbox(_ url: URL) -> Bool', STORE)
        self.assertIn('url.deletingLastPathComponent().standardizedFileURL', STORE)
        self.assertIn('let base = root.standardizedFileURL', STORE)
        # Deletion happens only after `published = true`, i.e. after the package is in place.
        published = STORE.index('published = true')
        removal = STORE.index('try? fm.removeItem(at: source)')
        self.assertLess(published, removal, 'the original must survive a failed adoption')

    def test_refresh_skips_a_file_already_adopted(self):
        # Second line of defence: a dropped file can reappear (iCloud sync, interrupted delete).
        self.assertIn('var existing = Set(try store.items().map', VIEW)
        self.assertIn('guard !existing.contains(key) else { continue }', VIEW)
        self.assertIn('if let item = try? store.importFile(url) { existing.insert', VIEW)

    def test_simulation_converges_over_repeated_refreshes(self):
        """Mirror the shipped algorithm: scan loose files, copy into a package, delete the source."""
        root = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, root, True)

        def refresh():
            adopted = []
            for entry in sorted(os.listdir(root)):
                path = root / entry
                if not path.is_file() or entry.startswith('.'):
                    continue
                package = root / f'pkg-{entry}'
                package.mkdir(exist_ok=True)
                shutil.copy2(path, package / entry)
                path.unlink()          # consume the dropped original
                adopted.append(entry)
            return adopted

        (root / 'Lab.ipa').write_bytes(b'x' * 1024)
        first = refresh()
        self.assertEqual(first, ['Lab.ipa'])
        # The bug's signature was growth here: with the original left behind, every refresh added
        # another 1 KB copy. Ten refreshes must now be no-ops and storage must stay flat.
        for _ in range(10):
            self.assertEqual(refresh(), [], 'repeated refresh must not re-adopt')
        self.assertEqual(sorted(p.name for p in root.iterdir() if p.is_file()), [])
        used = sum(f.stat().st_size for f in root.rglob('*') if f.is_file())
        self.assertEqual(used, 1024, 'total bytes on disk must equal the single adopted file')

    def test_re_dropping_the_same_file_still_works(self):
        root = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, root, True)
        for name in ('a.ipa', 'b.ipa'):
            (root / name).write_bytes(b'y' * 64)
            packages = [p for p in root.iterdir() if p.is_dir()]
            for entry in [e for e in os.listdir(root) if (root / e).is_file()]:
                (root / f'pkg-{entry}').mkdir(exist_ok=True)
                shutil.copy2(root / entry, root / f'pkg-{entry}' / entry)
                (root / entry).unlink()
        self.assertEqual(sorted(p.name for p in root.iterdir() if p.is_dir()), ['pkg-a.ipa', 'pkg-b.ipa'])
        self.assertEqual([e for e in os.listdir(root) if (root / e).is_file()], [])


if __name__ == '__main__':
    unittest.main()
