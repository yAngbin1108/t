# 修复记录（两轮）

## 第一轮：iOS 17.5.1 自签安装下"点打开没反应"

**根因**：SwiftUI `.fileImporter` 在 iOS 17.5.x + TrollStore/自签注入安装下，其内部文档选择器的完成回调链断裂——面板能弹出、能浏览，但点"打开"既不返回 URL 也不触发取消。项目自带的原生 `WorkspaceDocumentPicker`（直接封装 `UIDocumentPickerViewController`）不受影响，Git 导入与下载位置一直正常即是佐证。

**改动**：移除全部 4 处 `.fileImporter`，统一走原生 picker + `sheet(item:)`：
- `RepoPocket/WorkspaceDocumentPicker.swift` — `Kind` 增加 `custom([UTType])`，支持 .dylib / .deb 等类型过滤
- `RepoPocket/UploadView.swift` — 提交/发布选文件；顺带修掉取消时误报"只能选择 .dylib"
- `RepoPocket/ReleaseManagementUI.swift` — 发行版详情上传附件、编辑器追加附件
- `RepoPocket/DebEditorView.swift` — 从"文件"选择 .deb
- `Tests/test_file_importer_free.py` — 新增回归测试并接入 CI

**验证**：用户回传的操作录屏显示文件选择面板已可正常浏览与选取 ✅

---

## 第二轮："待上传文件"提示共享文件夹不可用

**这不是第一轮的 bug，是另一个独立问题。** 该界面读取 App Group 共享容器（`group.com.wm0104.RepoPocket.shared`），代码路径为 `ShareInboxStore.live()` → `containerURL(forSecurityApplicationGroupIdentifier:)` 返回 nil 即抛错，与文件选择器无关。

**根因**：iOS 只在「该 App Group 已注册给当前签名身份的 Team ID 前缀」时才发放容器。上游写死的 group 名配合假 team `TROLLTROLL` + ad-hoc 签名，**只有 TrollStore 安装才生效**。经 ESign / SideStore / AltStore 重签后 group 对不上证书，容器必然取不到——这与 IPA 是否包含分享扩展无关（打包步骤里的 `test -d ...appex` 已通过，说明扩展确实进了包）。

**改动**：
- `SharedInbox/ShareInboxStore.swift`
  - `group` 由硬编码常量改为**按调用解析**：依次尝试 Info.plist 覆盖键 `RPShareGroupIdentifier` → 代码签名里实际携带的 groups → 由 bundle id / `application-identifier` 推出的 **team 前缀写法**（`group.<TEAMID>.com.wm0104.RepoPocket.shared`）→ 最后才是原始规范名（放最后是为了让已有 TrollStore 安装继续看到旧文件）
  - 新增 `resolvedGroup(provision:)`，可在首次使用时创建收件箱目录，避免把失败结果永久缓存
  - 通过 `SecCodeCopySelf` + `SecCodeCopySigningInformation` 读回自身 entitlements（故新增 `import Security`）
  - 错误文案改为可操作的指引，不再只说"请确认使用支持分享扩展的安装方式"
- `RepoPocket/ShareInboxDiagnostics.swift`（新）+ 设置页入口 **"共享存储诊断"**：列出候选 group、哪个拿到了容器、当前收件箱文件数，便于在设备上直接定位
- `Tests/test_share_inbox_group.py`（新）并接入 CI

**注意**：本文件同时编译进主程序与分享扩展（`project.yml` 中两处 `sources` 都含 `SharedInbox`），扩展目标要求 `APPLICATION_EXTENSION_API_ONLY = YES`，因此未引入 UIKit。

---

## 仍然需要你在签名端配合的事

代码侧现在会**自动适配**你的重签工具写入的 group，多数情况下无需再配置。若诊断页显示所有候选都是 ✗，说明系统压根没给这个安装包任何 App Group 授权，此时必须二选一：

1. **改用 TrollStore 安装**（iOS 17.5.1 若仍可用则最省事）——原样安装本 IPA，不重签，group 直接生效
2. **在自签工具里补 App Group**：ESign/SideStore 需在签名选项里填 group，且**主程序与 `PlugIns/RepoPocketShare.appex` 必须填同一个值**；免费个人证书通常要求写成 `group.<你的TeamID>.com.wm0104.RepoPocket.shared`，付费账号还需在开发者后台为两个 App ID 勾选同一 Group

---

## 重新打包

流程不变：zip 传仓库 → Actions → Run workflow → Artifacts 下载 `RepoPocket.ipa`。
Entitlements、project.yml、构建脚本均未改动。
