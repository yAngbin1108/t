# 修复：iOS 17.5.1 自签安装下无法选择/上传下载文件

## 问题现象

在 iOS 17.5.1 上通过 TrollStore / 自签方式安装 RepoPocket 后：

- 上传文件时，系统文件选择面板可以弹出，也能浏览文件，但点击 **“打开”没有任何反应**——既不返回所选文件，也不触发取消回调，导致永远无法完成选择与上传。
- 下载相关流程同样受影响（凡是需要经过该选择面板的环节都会卡死）。

## 根因

代码里存在两套文件选择实现：

| 功能 | 实现 | 17.5.1 自签安装下的表现 |
|---|---|---|
| Git 仓库导入、下载位置选择、本地项目导入 | `WorkspaceDocumentPicker`（直接封装 `UIDocumentPickerViewController`） | ✅ 正常 |
| 上传选文件、Release 附件上传、deb 编辑选源文件 | SwiftUI `.fileImporter` | ❌ “打开”无响应 |

`.fileImporter` 内部呈现文档选择器的方式，在 iOS 17.5.x + 非沙盒注入安装（TrollStore/自签，无 App Store 沙盒与分享扩展容器上下文）下，其完成回调链断裂：用户点“打开”后，`Result<[URL], Error>` 的 completion handler 永远不会被调用，因此 UI 表现为按钮失灵。

项目其实早已知道 `.fileImporter` 不可靠——`WorkspaceDocumentPicker.swift` 的原注释就写着“Native picker avoids SwiftUI fileImporter's … regressions”，Git 导入和下载位置都改用了原生实现；只是上传相关的四处漏改了。这也解释了为什么作者在 iOS 16 上测试一切正常（16 上 `.fileImporter` 尚可用），而用户在 17.5.1 上必现。

## 修改内容

彻底移除所有 `.fileImporter`，统一走已验证可用的原生 `WorkspaceDocumentPicker` + `sheet(item:)` 呈现模式：

1. **RepoPocket/WorkspaceDocumentPicker.swift**
   - `WorkspaceImportRequest.Kind` 新增 `custom([UTType])` 分支，支持任意内容类型过滤（如仅 `.dylib`、仅 `.deb`），保持与原 `fileImporter` 相同的严格筛选能力。
   - 更新注释，记录 iOS 17.5 侧载安装的回归原因。

2. **RepoPocket/UploadView.swift**（提交/发布 → 选择文件）
   - `picking: Bool` → `pickerRequest: WorkspaceImportRequest?`；
   - TrollFools 模式仍限定 `.dylib`，普通模式为 `[.item]`；多选逻辑不变（`allowsMultipleSelection: mode == 0`）；
   - 取消（urls 为 nil 或空）不再误走 `select(.success([]))`，避免原来 dylib 模式下取消会弹“只能选择 .dylib 文件”的错误提示。

3. **RepoPocket/ReleaseManagementUI.swift**
   - 发行版详情“上传附件”、发行版编辑器“选择文件 / 追加附件”两处 `.fileImporter` 改为原生选择器 sheet；
   - 附件多选 → `stage(.success(urls))` 链路保持不变。

4. **RepoPocket/DebEditorView.swift**
   - “从‘文件’选择 .deb”改用原生选择器（类型仍为 deb + data），并移除了原先多余的 `onDismiss` 副作用。

5. **Tests/test_file_importer_free.py**（新增回归测试）
   - 静态契约：任何视图源码不得再出现 `.fileImporter`；各上传入口必须经由带请求身份的 `sheet(item:)` + `WorkspaceDocumentPicker`；
   - 已接入 `.github/workflows/build.yml`（CI 中 `test_build_workflow.py` 会校验 Tests/*.py 与工作流步骤一一对应）。

6. **Tests/test_deb_ui_static.py**
   - 同步更新 deb 选择器的契约断言。

## 行为差异说明

- 原生选择器以全屏 sheet 呈现（原 `fileImporter` 在 iPhone 上同样是全屏），交互一致；“取消”按钮语义不变。
- 选择结果仍在回调内立即 `copyItem` 到临时目录，安全作用域访问（`startAccessingSecurityScopedResource`）逻辑未改动。

## 验证

- `python3 Tests/test_swift_structure.py` — 全部 108 个 Swift 源括号/字符串结构平衡 ✅
- `python3 Tests/test_workspace_picker.py`、`test_share_social.py`、`test_release_management.py`、`test_repo_queue.py`、`test_deb_ui_static.py`、`test_build_workflow.py` 等可运行静态契约测试全部通过 ✅
- 新增 `Tests/test_file_importer_free.py` 5 项断言全部通过 ✅
- （依赖 swiftc/git 的运行时测试需在 macOS CI runner 上执行，本机环境不含 Swift 工具链，属预期跳过。）

## 重新打包

按原 CI 流程即可：`xcodegen generate && xcodebuild … && codesign --entitlements Entitlements.plist`，或用你自己的签名工具（ESign/SideStore 等）对编译产物重签。Entitlements、project.yml 均未改动。
