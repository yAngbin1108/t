
---

## 第四轮：真正的根因 —— 选择器被当成子控制器嵌入

第三轮后实测：作者原本就有的 `WorkspaceDocumentPicker`（Git 导入、下载位置）**同样**点「打开」无反应。
说明第一轮的 fileImporter 判断只是表象，真因在共享的呈现方式上：

`WorkspacePickerContainer` 用 `addChild(picker)` 把 `UIDocumentPickerViewController` **嵌入**为子控制器，
目的是在 provider 藏掉系统「取消」按钮时，自己在外面补一条取消栏。

但 `UIDocumentPickerViewController` 完成「打开」的方式是**先 dismiss 自己的 presenting 控制器、
再回调 `didPickDocumentsAt`**。作为子控制器它没有 presenting 控制器，iOS 17 上这个点击被静默丢弃：
面板不关、URL 不来、也不算取消 —— 正是用户描述的症状。

**修法**：改为 modal `present(picker, animated:)`，「取消」注入到选择器自己的
`navigationItem.leftBarButtonItem`（仅当 provider 未提供时）。

`Tests/test_workspace_picker.py` 原先断言 `addChild(picker)` 必须存在 —— 它把这个 bug 写成了契约，
已反转为断言 modal 呈现并禁止 `addChild` / `didMove(toParent`。
