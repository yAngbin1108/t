
## 第五轮：移植到作者 v1.1.1 + 修下载"请重新授权下载位置"

作者新增 `downloadCompletionNotice`（下载完成提示）等 2 个文件，全部保留，只做定点移植。

**真机报"下载失败：请重新授权下载位置。"的根因**：`resolve()` 无书签时返回**父目录** `Documents`，
而 `isInternal()` 拿它和**子目录** `Documents/RepoPocket` 比前缀 → 父永远不可能是子的前缀 → 判为外部
→ 对自有沙盒路径调用 `startAccessingSecurityScopedResource()` 返回 false → 抛错。

**修法**：新增 `DownloadRules.sandboxDocuments`（沙盒 Documents 根），`isInternal` 改为
`target == base || target.hasPrefix(base + "/")`。并补了行为级测试直接断言
`isInternal(resolve() 的返回值) == true`。
